module.exports = mongoose => {
    const Employee = mongoose.model(
      "employee",
      mongoose.Schema(
        {
          name: String,
          gender: String,
          dateofbirth: Date,
          salary: String,

        },
        { timestamps: true }
      )
    );
  
    return Employee;
  };